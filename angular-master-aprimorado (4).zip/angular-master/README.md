# angular-crud
MVP de cadastro de produto.
A API é considerada uma API Fake, feito em jsom server

## Melhorias

A aplicação também possui login com sessão, proteção de rotas, busca, filtros por nome e faixa de preço, ordenação, paginação, validação, estados de carregamento, mensagens de sucesso/erro e confirmação antes da exclusão.

Para demonstração, use `admin@admin.com` com a senha `123456`.

Execute o backend com `cd backend && npm start` e o frontend com `cd frontend && npm install && npm start`.

# Área como main
![Captura de Tela 2021-03-15 às 22 19 41](https://user-images.githubusercontent.com/39349326/111242163-5d07f000-85dd-11eb-8f58-e2fdb4a24165.png)

# Ambiente de visualização, edição e excluir
![Captura de Tela 2021-03-15 às 22 22 20](https://user-images.githubusercontent.com/39349326/111242263-96d8f680-85dd-11eb-952b-730a6975da69.png)

# Ambiente de cadastro
![Captura de Tela 2021-03-15 às 22 20 26](https://user-images.githubusercontent.com/39349326/111242309-aa845d00-85dd-11eb-9b29-dbaff689eefe.png)


