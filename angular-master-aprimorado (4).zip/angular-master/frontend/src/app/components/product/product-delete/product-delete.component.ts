import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from './../product.service';
import { Product } from './../product.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-delete',
  templateUrl: './product-delete.component.html',
  styleUrls: ['./product-delete.component.css']
})
export class ProductDeleteComponent implements OnInit {
  product: Product
  loading = true;
  deleting = false;
  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {

    const id = +this.route.snapshot.paramMap.get('id')
    this.productService.readById(id).subscribe(product => {
      this.product = product
      this.loading = false;

    })
  }
  deleteProduct(): void {
    if (!this.product || !window.confirm(`Deseja realmente excluir o produto "${this.product.name}"?`)) {
      return;
    }
    this.deleting = true;
    this.productService.delete(this.product.id).subscribe(() => {
      this.deleting = false;
      this.productService.showMessage('Produto excluído com sucesso')
      this.router.navigate(['/products'])
    }, () => this.deleting = false)
  }
  cancel(): void {
    this.router.navigate(['/products'])
  }
}
