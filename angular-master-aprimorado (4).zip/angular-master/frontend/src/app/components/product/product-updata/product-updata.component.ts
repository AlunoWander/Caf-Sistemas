import { Product } from './../product.model';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-updata',
  templateUrl: './product-updata.component.html',
  styleUrls: ['./product-updata.component.css']
})
export class ProductUpdataComponent implements OnInit {

  product: Product
  loading = true;
  saving = false;
  confirming = false;
  formError = '';
  // 1º passo pra fazer com que os dados venham p poder alterar
  // e em seguida faz a injeção no constructor "private route: ActivatedRoute"
  // e no iniciar ngOnInit, já coloca "this.productService.readById;"
  // depois faz a complementação como diz os proximos comentários


  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id')
    this.productService.readById(id).subscribe(product => {
      this.product = product;
      this.loading = false;
    });

  }

  updateProduct(): void {
    this.formError = '';
    if (!this.product || !this.product.name || this.product.name.trim().length < 2 || this.product.price === null || this.product.price === undefined || Number(this.product.price) < 0) {
      this.formError = 'Informe um nome válido e um preço maior ou igual a zero.';
      return;
    }
    this.confirming = true;
  }

  confirmUpdate(): void {
    this.confirming = false;
    this.saving = true;
    this.productService.updata(this.product).subscribe(() => {
      this.saving = false;
      this.productService.showMessage('Produto atualizado com sucesso!');
      this.router.navigate(['/products']);
    }, () => this.saving = false)
  }
  cancelConfirmation(): void {
    this.confirming = false;
  }

  cancel(): void {
    this.router.navigate(['/products']);
  }

}
