import { Product } from './../product.model';
import { ProductService } from './../product.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {
  loading = false;

  product: Product = {
    name: '',
    price: null
  }

  constructor(private productService: ProductService,
    private router: Router) { }


  ngOnInit(): void {

  }

  createProduct(form?: NgForm): void {
    if (!this.product.name || this.product.name.trim().length < 2 || this.product.price === null || this.product.price === undefined || Number(this.product.price) < 0 || (form && form.invalid)) {
      if (form) Object.keys(form.controls).forEach(key => form.controls[key].markAsTouched());
      return;
    }
    this.loading = true;
    this.productService.create(this.product).subscribe(() => {
      this.loading = false;
      this.productService.showMessage('Produto criado')
      this.router.navigate(['/products'])
    }, () => this.loading = false)


  }

  cancel(): void {
    this.router.navigate(['/products'])
  }
}
