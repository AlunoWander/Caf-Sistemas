import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Product } from './../product.model';
import { ProductService } from './../product.service';

@Component({
  selector: 'app-product-read',
  templateUrl: './product-read.component.html',
  styleUrls: ['./product-read.component.css']
})
export class ProductReadComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  products: Product[] = [];
  dataSource = new MatTableDataSource<Product>([]);
  displayedColumns = ['id', 'name', 'price', 'action'];
  search = '';
  minPrice: any = null;
  maxPrice: any = null;
  loading = true;
  sortColumn = 'id';
  sortDirection: 'asc' | 'desc' = 'asc';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.loading = true;
    this.productService.read().subscribe(products => {
      this.products = products || [];
      this.dataSource.data = this.products;
      this.loading = false;
      this.applyFilters();
    }, () => this.loading = false, () => this.loading = false);
  }

  applyFilters(): void {
    const search = this.search.trim().toLowerCase();
    const min = this.minPrice === null || this.minPrice === undefined || this.minPrice === '' ? null : Number(this.minPrice);
    const max = this.maxPrice === null || this.maxPrice === undefined || this.maxPrice === '' ? null : Number(this.maxPrice);
    const filtered = this.products.filter(product => {
      const price = Number(product.price);
      return (!search || product.name.toLowerCase().includes(search)) &&
        (min === null || price >= min) && (max === null || price <= max);
    });
    filtered.sort((a, b) => this.compareProducts(a, b));
    this.dataSource.data = filtered;
    if (this.paginator) {
      this.paginator.firstPage();
    }
  }

  sortBy(column: string): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
    this.applyFilters();
  }

  compareProducts(a: Product, b: Product): number {
    let result: number;
    if (this.sortColumn === 'id' || this.sortColumn === 'price') {
      result = Number(a[this.sortColumn]) - Number(b[this.sortColumn]);
    } else {
      result = String(a[this.sortColumn] || '').localeCompare(String(b[this.sortColumn] || ''), 'pt-BR', { sensitivity: 'base' });
    }
    return this.sortDirection === 'asc' ? result : -result;
  }

  onSortChange(sort: Sort): void {
    this.sortColumn = sort.active;
    this.sortDirection = sort.direction === 'desc' ? 'desc' : 'asc';
    this.applyFilters();
  }

  clearFilters(): void {
    this.search = '';
    this.minPrice = null;
    this.maxPrice = null;
    this.applyFilters();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }
}
