import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly sessionKey = 'angular-master-session';
  private readonly sessionSubject = new BehaviorSubject<boolean>(sessionStorage.getItem(this.sessionKey) === 'authenticated');
  readonly session$ = this.sessionSubject.asObservable();

  constructor(private router: Router) {}

  isLoggedIn(): boolean {
    return sessionStorage.getItem(this.sessionKey) === 'authenticated';
  }

  login(email: string, password: string): Observable<boolean> {
    const valid = email.trim().toLowerCase() === 'admin@admin.com' && password === '123456';
    if (valid) {
      sessionStorage.setItem(this.sessionKey, 'authenticated');
      this.sessionSubject.next(true);
    }
    return of(valid);
  }

  logout(): void {
    sessionStorage.removeItem(this.sessionKey);
    this.sessionSubject.next(false);
    this.router.navigate(['/login']);
  }
}
