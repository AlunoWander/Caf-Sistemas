import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  credentials = { email: '', password: '' };
  loading = false;
  errorMessage = '';

  constructor(private authService: AuthService, private router: Router) {}

  login(form: NgForm): void {
    this.errorMessage = '';
    if (form.invalid) {
      Object.keys(form.controls).forEach(key => form.controls[key].markAsTouched());
      return;
    }

    this.loading = true;
    this.authService.login(this.credentials.email, this.credentials.password).subscribe(valid => {
      this.loading = false;
      if (valid) {
        this.router.navigate(['/products']);
      } else {
        this.errorMessage = 'E-mail ou senha inválidos.';
      }
    });
  }
}
