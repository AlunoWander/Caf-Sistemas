import { Component } from '@angular/core';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.componnt.html'
})
export class AppComponent {
  isAuthenticated = false;

  constructor(public authService: AuthService) {
    this.authService.session$.subscribe(value => this.isAuthenticated = value);
  }
}
